<div class="footer">
	&copy; Wayne Herridge <?php print date("Y");?>
</div>